import java.util.ArrayList;
public class MainClass {

	public static void main(String[] args) {
		ArrayList<Associate> associateList = new ArrayList<Associate>();
		associateList.add(new Associate(101, 999, "Anmol"));
		associateList.add(new Associate(102, 333, "Nikhil"));
		associateList.add(new Associate(103, 555, "Abhishek"));
		
		Associate associateToBeSearched = new Associate(102, 333, "Nikhil");
		System.out.println(associateList.indexOf(associateToBeSearched));
		System.out.println(associateList.contains(new Associate(102, 333, "Nikhil")));
		
		for(Associate associate : associateList)
			if(associate.getAssociateId()==103 && associate.getName().equals("Abhishek"));
		System.out.println("Trueeeeee");
	}
}
