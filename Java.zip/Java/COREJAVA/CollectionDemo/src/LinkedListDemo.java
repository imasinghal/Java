import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class LinkedListDemo {
	public static void main(String[] args) {
		LinkedList<String> linkedList= new LinkedList<String>();

		linkedList.add("Nik");
		linkedList.add("Abhi");
		linkedList.add("Anm");
		linkedList.add("Ama");

	}

}