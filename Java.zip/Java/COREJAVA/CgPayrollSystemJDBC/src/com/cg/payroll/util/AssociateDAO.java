package com.cg.payroll.util;

import java.sql.SQLException;
import java.util.ArrayList;
public interface AssociateDAO {
	Associate save(Associate associate) throws SQLException;
	Associate findOne(int associateID) throws SQLException;
	ArrayList<Associate> findAll() throws SQLException;
	boolean update(Associate associate);
}
