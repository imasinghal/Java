package com.cg.payroll.util;

import java.util.ArrayList;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public interface PayrollServices {
	int acceptAssociateDetails(String firstName, String lastName,String department,String designation,String pancard,
			String emailid,int associateID, int yearlyInvestmentUnder80,String bankName,String ifscCode, int accountNumber,
			int epf, int companyPf, int basicSalary) throws PayrollServicesDownException;

	int calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException, PayrollServicesDownException;

	Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException , PayrollServicesDownException;
	Associate[] getAllAssociatesDetails()throws PayrollServicesDownException;

	ArrayList<Associate> getAllAssociateDetails()
			throws PayrollServicesDownException;
}
