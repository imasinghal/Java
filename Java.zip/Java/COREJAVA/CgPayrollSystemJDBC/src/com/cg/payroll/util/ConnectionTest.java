package com.cg.payroll.util;

import com.cg.payroll.util.ConnectionProvider;
import oracle.jdbc.driver.OracleDriver;
public class ConnectionTest {


	public static void main(String[] args) {
		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Connection open");
		else
			System.out.println("Connection closed");
	}

}
