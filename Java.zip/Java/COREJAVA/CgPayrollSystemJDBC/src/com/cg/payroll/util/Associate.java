package com.cg.payroll.util;

public class Associate {
	@Override
	public String toString() {
		return "Associate [associateID=" + associateID
				+ ", yearlyInvestmentUnder80=" + yearlyInvestmentUnder80
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", department=" + department + ", designation=" + designation
				+ ", pancard=" + pancard + ", emailid=" + emailid
				+ ", bankDetails=" + bankDetails + ", salary=" + salary + "]";
	}


	private int associateID,yearlyInvestmentUnder80;
	private String firstName,lastName,department,designation,pancard,emailid;
	private BankDetails bankDetails;
	private Salary salary;
	private static int ASSOCIATE_COUNTER=111;
	
	public static int getASSOCIATE_COUNTER(){
		return ASSOCIATE_COUNTER;
	}

	public Associate() {
		super();
	}

	public int getAssociateID() {
		return associateID;
	}

	public void setAssociateID(int associateID) {
		this.associateID = associateID;
	}

	public int getYearlyInvestmentUnder80() {
		return yearlyInvestmentUnder80;
	}

	public void setYearlyInvestmentUnder80(int yearlyInvestmentUnder80) {
		this.yearlyInvestmentUnder80 = yearlyInvestmentUnder80;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	
	public BankDetails getBankDetails() {
		return bankDetails;
	}

	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}

	public Salary getSalary() {
		return salary;
	}

	public void setSalary(Salary salary) {
		this.salary = salary;
	}


	public Associate(int associateID, int yearlyInvestmentUnder80,
			String firstName, String lastName, String department,
			String designation, String pancard, String emailid,
			BankDetails bankDetails, Salary salary) {
		super();
		this.associateID = associateID;
		this.yearlyInvestmentUnder80 = yearlyInvestmentUnder80;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emailid = emailid;
		this.bankDetails = bankDetails;
		this.salary = salary;
	}

	public Associate(int yearlyInvestmentUnder80C, String firstName2,
			String lastName2, String department2, String designation2,
			String pancard2, String emailid2, BankDetails bankDetails2,
			Salary salary2) {
		// TODO Auto-generated constructor stub
	}	
}
