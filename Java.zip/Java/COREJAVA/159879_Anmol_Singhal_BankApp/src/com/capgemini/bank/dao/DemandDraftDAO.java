package com.capgemini.bank.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;;
public class DemandDraftDAO implements IDemandDraftDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException{
		try {
			conn.setAutoCommit(false);
			PreparedStatement state1 = conn.prepareStatement("insert into demand_draft values(Transaction_Id_Seq.nextval,?,?,?,?,?,?,?)");
			state1.setString(1, demandDraft.getCustomer_name());
			state1.setString(2, demandDraft.getIn_favor_of());
			state1.setString(3, demandDraft.getPhone_number());
			state1.setString(4, demandDraft.getDate_of_transaction());
			state1.setFloat(5, demandDraft.getDd_amount());
			state1.setFloat(6, demandDraft.getDd_commission());
			state1.setString(7, demandDraft.getDd_description());
			state1.executeUpdate();
			conn.commit();

			PreparedStatement state2 = conn.prepareStatement("select max(transaction_id) from demand_draft");
			ResultSet resset = state2.executeQuery();
			resset.next();
			int transaction_Id = resset.getInt(1);
			return transaction_Id;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException{
		PreparedStatement state1 = conn.prepareStatement("select * from demand_draft where transaction_id="+transactionId);
		ResultSet resset = state1.executeQuery();
		if(resset.next()){
			String customer_name = resset.getString("customer_name");
			String in_favor_of = resset.getString("in_favor_of");
			String phone_number =  resset.getString("phone_number");
			String date_of_transaction = resset.getString("date_of_transaction");
			float dd_amount = resset.getFloat("dd_amount");
			float dd_commission = resset.getFloat("dd_commission");
			String dd_description = resset.getString("dd_description");
			DemandDraft demandDraft = new DemandDraft(transactionId, customer_name, dd_description, phone_number, date_of_transaction, in_favor_of, dd_commission, dd_amount);
			return demandDraft;
		}
		else
			return null;
	}
}
