package com.capgemini.bank.service;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exceptions.BankServiceDownException;
import com.capgemini.bank.exceptions.InvalidTransactionIdException;
public class DemandDraftService implements IDemandDraftService{
	IDemandDraftDAO iDemandDraftDAO = new DemandDraftDAO();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws BankServiceDownException {
		try {
			return	iDemandDraftDAO.addDemandDraftDetails(demandDraft);
		} catch (SQLException e) {
			throw new BankServiceDownException("Banking Services Are Down Temprorarily!");
		}
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws InvalidTransactionIdException, BankServiceDownException {
		try {
			if(iDemandDraftDAO.getDemandDraftDetails(transactionId)==null)
				throw new InvalidTransactionIdException("Invalid Transaction Id is entered!");
			return	iDemandDraftDAO.getDemandDraftDetails(transactionId);
		} catch (SQLException e) {
			throw new BankServiceDownException("Banking Services Are Down Temprorarily!");
		}
	}
}
