package com.capgemini.bank.bean;
public class DemandDraft {
	int transaction_Id;
	String customer_name, dd_description;
	String phone_number;
	String date_of_transaction, in_favor_of;
	float dd_commission, dd_amount;
	public DemandDraft(String customer_name, String dd_description,
			String phone_number, String in_favor_of, float dd_amount) {
		super();
		this.customer_name = customer_name;
		this.dd_description = dd_description;
		this.phone_number = phone_number;
		this.in_favor_of = in_favor_of;
		this.dd_amount = dd_amount;

		if (this.dd_amount<=5000)
			this.dd_commission=10;
		else if (5000<this.dd_amount && this.dd_amount<=10000)
			this.dd_commission=41;
		else if (10000<this.dd_amount && this.dd_amount<=100000)
			this.dd_commission=51;
		else
			this.dd_commission=306;

	}
	public int getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(int transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getDd_description() {
		return dd_description;
	}
	public void setDd_description(String dd_description) {
		this.dd_description = dd_description;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getDate_of_transaction() {
		return date_of_transaction;
	}
	public void setDate_of_transaction(String date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}
	public String getIn_favor_of() {
		return in_favor_of;
	}
	public void setIn_favor_of(String in_favor_of) {
		this.in_favor_of = in_favor_of;
	}
	public float getDd_commission() {
		return dd_commission;
	}
	public void setDd_commission(float dd_commission) {
		this.dd_commission = dd_commission;
	}
	public float getDd_amount() {
		return dd_amount;
	}
	public void setDd_amount(float dd_amount) {
		this.dd_amount = dd_amount;
	}
	@Override
	public String toString() {
		return "DemandDraft [transaction_Id=" + transaction_Id
				+ ", customer_name=" + customer_name + ", dd_description="
				+ dd_description + ", phone_number=" + phone_number
				+ ", date_of_transaction=" + date_of_transaction
				+ ", in_favor_of=" + in_favor_of + ", dd_commission="
				+ dd_commission + ", dd_amount=" + dd_amount + "]";
	}
	public DemandDraft(int transaction_Id, String customer_name,
			String dd_description, String phone_number,
			String date_of_transaction, String in_favor_of,
			float dd_commission, float dd_amount) {
		super();
		this.transaction_Id = transaction_Id;
		this.customer_name = customer_name;
		this.dd_description = dd_description;
		this.phone_number = phone_number;
		this.date_of_transaction = date_of_transaction;
		this.in_favor_of = in_favor_of;
		this.dd_commission = dd_commission;
		this.dd_amount = dd_amount;
	}

}
