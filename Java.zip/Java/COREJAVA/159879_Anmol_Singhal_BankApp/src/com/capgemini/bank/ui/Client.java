package com.capgemini.bank.ui;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankServiceDownException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
public class Client {
	public static void main(String[] args) {
		String cusName, inFavorOf, ddDescription, phoneNum;	//Declaring Variables
		float ddAmount;
		System.out.println("1) Enter Demand Draft Details \n 2) Exit");
		Scanner scan = new Scanner(System.in);			//scanner to get user input
		int j = scan.nextInt();
		switch(j){				//Switch case for exit
		case 1:
			System.out.println("Enter Customer Name: ");
			cusName = scan.next();
			System.out.println("Enter Customer Contact Number: ");
			phoneNum = scan.next();
			System.out.println("In favor of: ");
			inFavorOf = scan.next();
			System.out.println("Enter DD Amount(in Rs): ");
			ddAmount = scan.nextFloat();
			System.out.println("Enter Remarks: ");
			ddDescription = scan.next();

			DemandDraft demandDraft = new DemandDraft(cusName, ddDescription, phoneNum, inFavorOf, ddAmount);			
			IDemandDraftService bankingService = new DemandDraftService();
			try {
				System.out.println("Your Demand Draft request has been successdully registered along with the  " +bankingService.addDemandDraftDetails(demandDraft));
				//bankingService.addDemandDraftDetails(demandDraft);
			} catch (BankServiceDownException e) {
				e.printStackTrace();
			}
			break;
		case 2:
			break;
		default:
			break;
		}
	}
}
