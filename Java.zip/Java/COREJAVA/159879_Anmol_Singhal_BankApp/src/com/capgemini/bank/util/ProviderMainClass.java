package com.capgemini.bank.util;

import com.capgemini.bank.util.ConnectionProvider;

public class ProviderMainClass {
	public static void main(String[] args) {
		if(ConnectionProvider.getDBConnection()==null)
			System.out.println("No Connection");
		else 
			System.out.println("Connection Done");
	}
}
