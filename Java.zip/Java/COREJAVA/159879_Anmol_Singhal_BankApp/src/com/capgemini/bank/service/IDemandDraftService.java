package com.capgemini.bank.service;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankServiceDownException;
import com.capgemini.bank.exceptions.InvalidTransactionIdException;
public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demandDraft) throws BankServiceDownException;
	DemandDraft getDemandDraftDetails (int transactionId) throws InvalidTransactionIdException, BankServiceDownException;

}
