package com.cg.inheritance.beans;

public class CEmployee {

}
