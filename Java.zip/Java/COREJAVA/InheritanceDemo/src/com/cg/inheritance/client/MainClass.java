package com.cg.inheritance.client;

import com.cg.inheritance.beans.CEmployee;
import com.cg.inheritance.beans.Employee;
import com.cg.inheritance.beans.PEmployee;

public class MainClass {
	public static void main(String[] args) {
		Employee employee=new Employee(123, "Anmol", "Singhal", 15000);
		employee.calculateTotalSalary();
		PEmployee pemp = new PEmployee(124, "Nikhil", "Mahesh", 17000);
		System.out.println(pemp.getEmployeeId());
		pemp.calculateTotalSalary();
		System.out.println(pemp.toString());
		
		CEmployee cemp= new CEmployee(103,"Aakash","Rao",500);
		cemp.calculateTotalSalary();
	}
}
