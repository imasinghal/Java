import com.cg.project.exceptions.InvalidNumberRangeException;
public class MathServicesImpli implements MathServices{
	
	@override
	public int addNums(int n1, int n2) throws InvalidNumberRangeException{
		
	}

}
