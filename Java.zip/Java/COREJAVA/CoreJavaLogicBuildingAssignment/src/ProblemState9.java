public class ProblemState9 {
	public static void main(String[] args) {
		int a[][] = {{0,1,9,3},{7,5,8,3},{9,2,9,1},{4,6,7,1}};
		int count=0;
		System.out.println(a.length);
		for(int i=1;i<a.length-1 ;i++){
			for(int j=1;j<a.length-1;j++){
				if(a[i][j-1]>a[i][j]&&a[i][j]<a[i][j+1]&& a[i-1][j]<a[i][j]&&a[i][j]>a[i+1][j])
					count++;
				if(a[i][j-1]<a[i][j]&&a[i][j]>a[i][j+1]&& a[i-1][j]>a[i][j]&&a[i][j]<a[i+1][j])
					count++;
			}
		}
		System.out.println(count);
	}

}