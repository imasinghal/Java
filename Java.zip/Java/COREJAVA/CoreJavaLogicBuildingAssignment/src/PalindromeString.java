public class PalindromeString {
	public static void main(String[] args){ 
		String input = "MOM"; 
		StringBuilder input1 = new StringBuilder(); 
		input1.append(input);
		input1 = input1.reverse(); 
		if(input.toString().equals(input1.toString()))
			System.out.println("The String is a Palindrome"); 
		else
			System.out.println("The String is not a palindrome"); 
	}
}	
