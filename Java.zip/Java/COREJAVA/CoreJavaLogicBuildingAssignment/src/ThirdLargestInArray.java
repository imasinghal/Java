public class ThirdLargestInArray {
	public static void main(String[] args) {
		int arr[]={4,3,56,5,9,26,27,55,66,101};
		int count=0;
		for(int i=0;i<arr.length;i++)
			for(int j=i+1;j<arr.length;j++)
				if(arr[i]>arr[j]){
					int temp=arr[j];
					arr[j]=arr[i];
					arr[i]=temp;
				}
		for(int i = arr.length-1;i>=0;i--){
			if(arr[i]==arr[i-1])
				continue;
			else{
				count++;
				if(count==2){
					System.out.println(arr[i-1]);
					break;
				}
				else 
					continue;
			}
		}
	}
}