public class OneTwoThreeDigitNum {
	public static void main(String[] args) {
		int numbers[]={12,25,8,9,354,1,369,235,741,0};
		int one=0,two=0,three=0;
		for (int i=0;i<numbers.length;i++){
			if(numbers[i]>=0&&numbers[i]<10)
				one++;
			else if(numbers[i]>=10 && numbers[i]<100)
				two++;
			else three++;
		}
		System.out.println("One digit numbers are "+one+"\nTwo digits numbers are "+two+"\nThree digit numbers are "+three);
	}
}