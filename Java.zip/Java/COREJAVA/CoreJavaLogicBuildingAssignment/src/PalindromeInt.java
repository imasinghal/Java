public class PalindromeInt {
	public static void main(String[] args) {
		int num = 1221, reverse = 0, remainder, firstNum;
		firstNum = num;
		while( num != 0 ){
			remainder = num % 10;
			reverse= reverse * 10 + remainder;
			num  /= 10;
		}
		if (firstNum == reverse)
			System.out.println(firstNum + " is a palindrome.");
		else
			System.out.println(firstNum + " is not a palindrome.");
	}
}