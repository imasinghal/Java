public class CountDigitsInArray {
	public static void main(String[] args) {
		int numberArray[]={15,666,879,1515,615,148,7230};
		int underTest=0;
		int one=0,two=0,three=0,four=0,five=0,six=0,seven=0,eight=0,nine=0,zero=0;
		for (int i=0;i<numberArray.length;i++){
			underTest=numberArray[i];
			while(underTest!=0){
				if(underTest%10==0)
					zero++;
				else if (underTest%10==1)
					one++;
				else if(underTest%10==2)
					two++;
				else if(underTest%10==3)
					three++;
				else if (underTest%10==4)
					four++;
				else if (underTest%10==5)
					five++;
				else if (underTest%10==6)
					six++;
				else if(underTest%10==7)
					seven++;
				else if (underTest%10==8)
					eight++;
				else if (underTest%10==9)
					nine++;
				underTest/=10;
			}
		}
		System.out.println("Zero occurs "+zero+" times");
		System.out.println("One occurs "+one+" times");
		System.out.println("Two occurs "+two+" times");
		System.out.println("Three occurs "+three+" times");
		System.out.println("Four occurs "+four+" times");
		System.out.println("Five occurs "+five+" times");
		System.out.println("Six occurs "+six+" times");
		System.out.println("Seven occurs "+seven+" times");
		System.out.println("Eight occurs "+eight+" times");
		System.out.println("Nine occurs "+nine+" times");
	}
}