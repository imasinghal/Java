public class Stack {
	static void push(int arr[],int position,int value){
		int len=arr.length;
		if(position>=len)
		{System.out.println("Stack is full");
		return;
		}
		arr[position]=value;
		return; 
	}
	static int pop(int arr[],int position){
		if (position<0){
			System.out.println("Stack is empty");
			return -1;
		}
		int value =arr[position];
		return value;
	}
	public static void main(String[] args) {
		int stacky[] = new int[10];
		int position=0;
		push(stacky,position++,10);
		push(stacky,position++,20);
		push(stacky,position++,30);
		System.out.println(pop(stacky,--position));
		System.out.println(pop(stacky,--position));
		System.out.println(pop(stacky,--position));
		System.out.println(pop(stacky,--position));
		//take input in check
	}
}