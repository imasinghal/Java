import java.util.Arrays;
public class HighestNumMadeOfNum {
	public static void main(String [] args){
		int number = 30017,  i = 0;
		int[] numList = new int[5];
		while(number!=0){
			numList[i] = number%10;
			number/=10;
			i++;
		}
		System.out.print("Highest number: ");
		Arrays.sort(numList);
		String s="";
		for(int j=numList.length-1;j>=0;j--)
			System.out.print(numList[j]);
		System.out.println(s);
		System.out.print("Smallest number: ");
		for(int j=0;j<numList.length;j++){
			if(numList[j]==0)
				continue;
			else
				System.out.print(numList[j]);
		}
	}
}