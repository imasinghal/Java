public class LinearArraySearch {
	public static void main(String[] args) {
		int linearArray[] = {1,2,3,4,5,6,7,8,9};
		int k=0;
		for (int x = 0; x < linearArray.length; x++) 
			if(linearArray[x]==5){
				System.out.println("Index="+x); 
				k=1;
				break;
			}
		if(k==0)
			System.out.println("No Num is found");
	}
}