@FunctionalInterface
public interface FunctionalInterface1 {
	void greetUser(); 
}
