@FunctionalInterface
public interface FunctionalInterface2 {
	int add(int a, int b);
}
