
public class MainClass {
	public static void main(String[] args) {
		FunctionalInterface1 f1=(
				) ->{
			System.out.println("Hellooooooo");
		};
		f1.greetUser();
		FunctionalInterface2 f2 = (a,b)->{
			System.out.println(a+b);
			return a+b; 
		};
			f2.add(100,200);
	}
}

