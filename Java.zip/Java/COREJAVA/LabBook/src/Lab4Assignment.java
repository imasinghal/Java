
public class Lab4Assignment {
	public static void main(String[] args) {
		/*//4.1
		Account acc1= new Account(2000, new Person("Smith"));
		Account acc2=new Account(3000,new Person("Kathy"));
		acc1.deposit(2000);
		acc2.withdraw(2000);
		System.out.println(acc1.getBalance());
		System.out.println(acc2.getBalance());
		System.out.println(acc1.toString());*/

		//4.2
		/*a)
		SavingsAccount sb1 = new SavingsAccount(3000, new Person("Nik"));
		sb1.withdraw(2500);
		System.out.println(sb1.getBalance());*/

		/*b)
		CurrentAccount cb = new CurrentAccount(6000, new Person("Nik"));
		cb.withdraw(4500);
		System.out.println(cb.getBalance());*/

	}
}