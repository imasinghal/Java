import java.util.Scanner;
public class Lab2Assignment {
	public static void main(String[] args) {
		/*2.1
		System.out.println("Personal Details: ");
		System.out.println("______________");
		System.out.println("");
		System.out.println("First Name: Divya");
		System.out.println("Last Name: Bharathi");
		System.out.println("Gender: F");
		System.out.println("Age: 20");
		System.out.println("Weight: 85.55");*/

		/*2.2
		int num;
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the number you want to check:");
		num = s.nextInt();
		if(num > 0)
			System.out.println("The given number "+num+" is Positive");
		else if(num < 0)
			System.out.println("The given number "+num+" is Negative");
		else
			System.out.println("The given number "+num+" is neither Positive nor Negative ");*/
	
		/*2.3
		Person person1 = new Person("Divya", "Bharathi", 'F');
		System.out.println("First Name: " +person1.getFirstName());
		System.out.println("Last Name: " +person1.getLastName());
		System.out.println("Gender: " +person1.getGender());*/

		/*2.4
		Person person1 = new Person("Divya", "Bharathi", 'F');
		person1.setPhone(person1.newPhone());
		person1.displayAll();*/
		
		//2.5
		Person person1 = new Person("Divya", "Bharathi", Gender.M);
		System.out.println("Gender: " +person1.getGender());
	}
}
