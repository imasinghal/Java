
public class Account {
	private long accountNum;
	private double balance;
	Person accountHolder = new Person();
	public long accountCounter = 1000000;
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long accountNum, double balance, Person accountHolder,
			long accountCounter) {
		super();
		this.accountNum = accountNum;
		this.balance = balance;
		this.accountHolder = accountHolder;
		this.accountCounter = accountCounter;
	}
	public long getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(long accountNum) {
		this.accountNum = accountNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(Person accountHolder) {
		this.accountHolder = accountHolder;
	}
	public long getAccountCounter() {
		return accountCounter;
	}
	public void setAccountCounter(long accountCounter) {
		this.accountCounter = accountCounter;
	}

}