import java.util.Scanner;

enum Gender{
	M,F;
}
public class Person {
	private String firstName, lastName;
	private Gender gender;
	private long phone;
	public Person(String firstName, String lastName, Gender gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public Person() {
		super();
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public long newPhone() {
		Scanner scr = new Scanner(System.in);
		System.out.print("Enter Phone number: ");
		long p = scr.nextLong();
		return p;
	}
	public void displayAll() {
		System.out.println(toString());
	}
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + ", phone=" + phone + "]";
	}

}
