import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;
public class Lab3Assignment {
	public static void main(String[] args) {
		/*//3.1
		System.out.println("Enter String: ");
		Scanner scan = new Scanner(System.in);
		String strng = scan.nextLine();
		StringBuilder strbld = new StringBuilder(strng);
		System.out.println("1) Add the String to itself");
		System.out.println("2) Replace odd positions with #");
		System.out.println("3) Remove duplicate characters in the String");
		System.out.println("4) Change odd characters to upper case");
		int num = scan.nextInt();
		switch (num) {
		case 1:
			strbld = strbld.append(strbld);
			System.out.println(strbld);
			break;
		case 2:
			for (int i=0;i<strbld.length();i++)
				if(i%2!=0)
					strbld.setCharAt(i, '#');
			System.out.println(strbld);
			break;
		case 3:
			String stb = "";
			for(int i=0;i<strng.length();i++){
				char c = strng.charAt(i);
				if(stb.indexOf(c)<0)
					stb = stb + c;
			}
			strng = stb;
			System.out.println(strng);
			break;
		case 4:
			for (int i=0;i<strbld.length();i++)
				if(i%2!=0){
					String s = strng.substring(i, i+1).toUpperCase();
					strbld.replace(i, i+1, s);
				}
			System.out.println(strbld);
			break;
		default:
			break;
		}*/

		//3.2
		/*Scanner s = new Scanner(System.in);
		String str = s.nextLine();
		char c[] = str.toCharArray();
		Arrays.sort(c);
		String sortedstr = new String(c);
		System.out.println();
		if(sortedstr.equals(str))
			System.out.println("Positive");
		else
			System.out.println("Negative");*/

		//3.7
		/*Scanner ref = new Scanner(System.in);
				String s = ref.next();
				if(s.substring(s.length()-4, s.length()).equals("_job") && s.substring(0, s.length()-4).length()>=8)
					System.out.println("True");
				else
					System.out.println("False");*/

		//3.8
		ArrayList<String> strList = new ArrayList<String>();
		strList.add("Anmol");
		strList.add("Aman");
		strList.add("Yara");
		Collections.sort(strList);
		System.out.println(strList);
		for(int i=0;i<strList.size();i++){
			if(strList.size()%2==0){
				if(i<(strList.size())/2)
					strList.set(i,	 strList.get(i).toUpperCase());
				else
					strList.set(i,	 strList.get(i).toLowerCase());
			}
			else
				if(i<(strList.size())/2+1)
					strList.set(i,	 strList.get(i).toUpperCase());	
				else
					strList.set(i,	 strList.get(i).toLowerCase());
		}
		System.out.println(strList);

	}
}