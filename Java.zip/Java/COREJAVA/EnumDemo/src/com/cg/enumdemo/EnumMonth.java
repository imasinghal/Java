package com.cg.enumdemo;

public enum EnumMonth {

	JAN(1,"JAN"),
	FEB(2,"feb"),
	MARCH(3,"MAR"),
	APRIL(4,"APR"),
	MAY(5,"MAY");
 
	private int monthIndex;
	private String monthName;
 
	private Month(){}
	private Month(int monthIndex, String monthName){
	this.monthIndex = monthIndex;
	this.monthName=monthName;
	}
public int getMonthIndex(){
	return monthIndex;
}
public void setMonthIndex(int monthindex){
	this.monthIndex=monthIndex;
}
 