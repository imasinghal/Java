package com.cg.payroll.client;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		//		Associate associate1 = new Associate(100, 2000000," Anmol", "Singhal", "Sr. Anly", "YTM", "KTHN1233335","ima.singhal96@gmail.com");
		//		Associate associate2= new Associate(101, 2000000," Nikhil", "Maheshwari", "Sr. Anly", "YTM", "UDHN1232235","nik.mahesh@gmail.com");
		//		Associate associate3= new Associate(102, 2000000," Abhishek", "Sharma", "Sr. Anly", "YTM", "UIDDI1234","abhi@gmail.com");
		//
		//		BankDetails associate1BankDetails= new BankDetails(11223399, 100, "HDFC"," HDFC002");
		//		BankDetails associate2BankDetails= new BankDetails(12223399, 101, "HDFC"," HDFC002");
		//		BankDetails associate3BankDetails= new BankDetails(13223399, 102, "HDFC"," HDFC002");
		//
		//		Salary associate1SalaryDetails=new Salary(22000, 5000, 10000, 2000, 2050, 3000, 3500, 3500, 600, 2000000, 1800000);
		//		Salary associate2SalaryDetails=new Salary(22000, 5000, 10000, 2000, 2050, 3000, 3500, 3500, 600, 2000000, 1800000);
		//		Salary associate3SalaryDetails=new Salary(22000, 5000, 10000, 2000, 2050, 3000, 3500, 3500, 600, 2000000, 1800000);
		//
		//		System.out.println("Pancard:"+associate1.getPancard());
		//		System.out.println("Bank Ifsc:"+associate2BankDetails.getIfscCode());
		//		System.out.println("EPF:"+associate2SalaryDetails.getEpf());
		//		System.out.println(Associate.getASSOCIATE_COUNTER());
		//		//associate1.setAssociateID(10001);//
			BankDetails associate1BankDetails= new BankDetails(100, 1122338899,"HDFC", "ifscCode");
				Salary associate1SalaryDetails= new Salary(22000, 5000, 10000, 2000, 2050, 3000, 3500, 3500, 600, 2000000, 1800000);
				Associate associate1= new Associate(100, 2000000," Anmol", "Singhal", "Sr. Anly", "YTM", "KTHN1233335","ima.singhal96@gmail.com", associate1BankDetails, associate1SalaryDetails);
				System.out.println("Bank Ifsc:"+associate1.getBankDetails().getAccountNumber());
				associate1.getSalary().setOtherAllowance(20*associate1.getSalary().getBasicSalary()/100);
				System.out.println(associate1.getSalary().getOtherAllowance());
				associate1.setSalary(new Salary(55));
			System.out.println(associate1.getSalary().getHra());
		PayrollServices payrollServices = new PayrollServicesImpl();
		
	}
}
