package com.cg.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
public class AssociateDAOImpl implements AssociateDAO{

	private Connection conn=ConnectionProvide.getDBConnection();

	private static  Associate []  associates = new Associate[10];
	private static int ASSOCIATE_IDX=0;
	private static int ASSOCIATE_ID_COUNTER=101;

	@Override
	public Associate save(Associate associate) {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1= conn.prepareStatement("insert into Associate values(?,?,?,?,?,?,?)");
			pstmt1.setInt(1, associate.getYearlyInvestmentUnder80());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.executeUpdate();

			PreparedStatement pstmt2 = conn.prepareStatement("select max(associateId) from Associate");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int associatId = rs.getInt(1); // 1 is the index of column in select statement

			PreparedStatement pstmt3 = conn.prepareStatement("insert into BankDetails value(?,?,?,?)");
			int associateId;
			pstmt3.setInt(1,associateId);
			//same for all columns
			pstmt3.executeUpdate();

			PreparedStatement pstmt4 = conn.prepareStatement("insert into Salary value(associateId,basicSalary,epf,compf)");
			pstmt4.setInt(1,associateId);
			pstmt4.setInt(2,associate.getSalary().getBasicSalary());
			//same for others
			pstmt4.executeUpdate();
			conn.commit();
			associate.setAssociateID(associateId);
			return associate;

		}
		catch(SQLException e){
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associates[ASSOCIATE_IDX++]=associate;
		return associate;
	}
	@Override
	public Associate findOne(int associateId) throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("Select * frm Associate where associateId="+associateId);
		ResultSet associateRS = pstmt1.executeQuery();
		if(associateRS.next()){
			String firstName=associateRS.getString("firstName");
			String lastName=associateRS.getString("lastName");
			//same for other fields
			//Associate associate = new Associate(give details);
			PreparedStatement pstmt2 = conn.prepareStatement("Select * frm BndkDetails where associateIsd="+associateId);
			ResultSet bankdetailsRS = pstmt2.executeQuery();
			bankdetailsRS.next();

			int accountNumber = bankdetailsRS.getInt("accountNumber");
			String bankname = bankdetailsRS.getString("bankname");
			String ifscode = bankdetailsRS.getString("ifscCode");
			associate.setBankDetails(new BankDetails(accountNumber,bankname,ifscode));

			PreparedStatement pstmt3 = conn.prepareStatement("Select * frm Salary where associateId="+associateId);
			for(int i=0;i<associates.length;i++) 
				if(associates[i]!=null&& associateId==associates[i].getAssociateID())
					return associates[i];
		}
		return null;
	}
	@Override
	public Associate[] findAll() {
		return associates;
	}



}