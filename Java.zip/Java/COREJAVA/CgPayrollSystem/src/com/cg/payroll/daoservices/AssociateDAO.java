package com.cg.payroll.daoservices;
import java.sql.SQLException;

import com.cg.payroll.beans.Associate;
public interface AssociateDAO {
	Associate save(Associate associate);
	Associate findOne(int associateID) throws SQLException;
	Associate[] findAll();
}
