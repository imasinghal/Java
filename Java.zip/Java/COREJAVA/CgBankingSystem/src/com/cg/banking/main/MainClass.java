package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServices bankingServices = new BankingServicesImpl();
		/*System.out.println("Hello! Welcome to Banking System");
		System.out.println("Choose the required Service");
		System.out.println(" 1) Open Account \n 2) Deposit Amount \n 3) Withdraw Amount \n 4) Fund Transfer \n 5) Get Account Details \n 6) Get All Account Details \n 7) Get All Transactions for Account \n 8) Check Account Status");*/
		try {
			bankingServices.openAccount("Savings", 4000);
			bankingServices.openAccount("Savings", 3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
            bankingServices.depositAmount(100002, 3000);
			bankingServices.withdrawAmount(100002, 1000,1112);
			//System.out.println("Amount Deposited in Account Number "+account.getAccountNo()+" is : "+account.getAccountBalance());
			//bankingServices.fundTransfer(100001, 100002, 999, 1112);
			//System.out.println(bankingServices.getAccountDetails(100001));
			//System.out.println(bankingServices.getAllAccountDetails());
		} catch (Exception e) {
			e.printStackTrace();
		}
		/*try {
			Account account = bankingServices.withdrawAmount(100001, 1000,1111);
			System.out.println("Amount Withdrawn from Account Number "+account.getAccountNo()+" is : "+account.getAccountBalance());
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			bankingServices.fundTransfer(100001, 100002, 999, 1112);
			Account account = bankingServices.getAccountDetails(100001);
			System.out.println("Account Balance after Fund Transfer is : "+account.getAccountBalance());
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
				bankingServices.getAccountAllTransaction(100001);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
}
