package com.cg.banking.services;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	private static AccountDAO accountDAO = new AccountDAOImpl();
	//private ArrayList<Transaction> transactionList = new ArrayList<>();
	
	
	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account = new Account(accountType, initBalance);
		if(account.getAccountBalance()<1000)
			throw new InvalidAmountException("Minimum account balance should be 1000!");
		try {
			account = accountDAO.save(account);
			//account.setTransaction(new Transaction(initBalance, "New Account"));
			return account.getAccountNo();
		} catch (SQLException e) {
			throw new BankingServicesDownException("Banking Services Down");
		}
		//transactionList.add(new Transaction(initBalance, "New Account"));
		
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		try {
			Account account = accountDAO.find(accountNo);
			if(account==null)
				throw new AccountNotFoundException("Please enter a valid account number!");
			/*account.setAccountBalance(account.getAccountBalance()+amount);
			//transactionList.add(new Transaction(amount, "Deposit"));
			account.setTransaction(new Transaction(amount, "Deposit"));*/
			return accountDAO.updateDeposit(accountNo, amount);
		} catch (SQLException e) {
			throw new BankingServicesDownException("Banking Services Down");
		}	
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		Account account = new Account();
		try {
			account = accountDAO.find(accountNo);
			if(account==null)
				throw new AccountNotFoundException("Please enter a valid account number!");
			else if(account.getAccountBalance()-amount<0)
				throw new InsufficientAmountException("Please Enter a Valid Amount");
			else if(account.getPinNumber()!=pinNumber)
				throw new InvalidPinNumberException("Enter a valid PinNumber");
			/*account.setAccountBalance(account.getAccountBalance()-amount);
			//transactionList.add(new Transaction(amount, "Withdraw"));
			account.setTransaction(new Transaction(amount, "Withdraw"));*/
			return accountDAO.updateWithdraw(accountNo, amount);
		} catch (SQLException e) {
			throw new BankingServicesDownException("Banking Services Down");
		}
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account acc1,acc2;
		try {
			acc1 = accountDAO.find(accountNoTo);
			acc2 = accountDAO.find(accountNoFrom);
			if(acc2.getAccountBalance()<transferAmount)
				throw new InsufficientAmountException("Please Enter a Valid Amount!");
			if(acc2.getPinNumber()!=pinNumber)
				throw new InvalidPinNumberException("Enter a valid PinNumber");
			accountDAO.updateDeposit(accountNoTo, transferAmount);
			accountDAO.updateWithdraw(accountNoFrom, transferAmount);
		} catch (SQLException e) {
			throw new BankingServicesDownException("Banking Services Down");
		}
		
		
		//transactionList.add(new Transaction(transferAmount, "Fund Transfer"));
		//acc1.setTransaction(new Transaction(transferAmount, "Fund Transfer : Deposit"));
		//acc2.setTransaction(new Transaction(transferAmount, "Fund Transfer : Withdraw"));
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account;
		try {
			account = accountDAO.find(accountNo);
		} catch (SQLException e) {
			throw new BankingServicesDownException("Banking Services Down");
		}
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		try {
			return accountDAO.findAll();
		} catch (SQLException e) {
			throw new BankingServicesDownException("Banking Services Down");
		}
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		try {
			return accountDAO.allTransactions(accountNo);
		} catch (SQLException e) {
			throw new BankingServicesDownException("Banking Services Down");
		}
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account;
		try {
			account = accountDAO.find(accountNo);
		} catch (SQLException e) {
			throw new BankingServicesDownException("Banking Services Down");
		}
		return account.getStatus();
	}

}
