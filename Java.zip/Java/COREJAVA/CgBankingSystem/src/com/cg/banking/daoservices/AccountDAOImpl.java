package com.cg.banking.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.ConnectionProvider;

public class AccountDAOImpl implements AccountDAO{

	private Connection conn=ConnectionProvider.getDBConnection();
	ArrayList<Account> accList = new ArrayList<Account>();
	@Override
	public Account save(Account account) throws SQLException {
		//accList.add(account);
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("insert into Account(accountNo,accountBalance,pinNumber,accountType,status) values(?,?,?,?,?)");
			pstmt1.setLong(1, account.getAccountNo());
			pstmt1.setFloat(2, account.getAccountBalance());
			pstmt1.setInt(3, account.getPinNumber());
			pstmt1.setString(4, account.getAccountType());
			pstmt1.setString(5, account.getStatus());
			pstmt1.executeUpdate();
			
			/*PreparedStatement pstmt2 = conn.prepareStatement("select max(accountNo) from Account");			
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			long accountNo = rs.getInt(1);*/
			
		/*	PreparedStatement pstmt3 = conn.prepareStatement("insert into Transaction values(?,?,?,?)");
			pstmt3.setLong(1, accountNo);
			pstmt3.setInt(2, account.getTransaction().getTransactionId());
			pstmt3.setFloat(3, account.getTransaction().getAmount());
			pstmt3.setString(4, account.getTransaction().getTransactionType());
			pstmt3.executeUpdate();*/
			conn.commit();
			return account;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}
	@Override
	public Account find(long accountNo) throws SQLException {
/*		for (Account acc : accList)
			if(acc.getAccountNo()==accountNo)
				return acc;*/
		PreparedStatement pstmt1 = conn.prepareStatement("select * from Account where accountNo="+accountNo);
		ResultSet accountRS = pstmt1.executeQuery();
		if(accountRS.next()){
			String accountType = accountRS.getString("accountType");
			String status = accountRS.getString("status");
			int pinNumber = accountRS.getInt("pinNumber");
			float accountBalance = accountRS.getFloat("accountBalance");
			Account account = new Account(pinNumber, accountType, status, accountBalance, accountNo,null);
			
			/*PreparedStatement pstmt2 = conn.prepareStatement("select * from Transaction where accountNo="+accountNo);
			ResultSet transactionRS = pstmt2.executeQuery();
			transactionRS.next();
			float amount = transactionRS.getFloat("amount");
			int transactionId = transactionRS.getInt("transactionId");
			String transactionType = transactionRS.getString("transactionType");
			account.setTransaction(new Transaction(transactionId, amount, transactionType));*/
			return account;
		}
		return null;
	}
	@Override
	public ArrayList<Account> findAll() throws SQLException {
		//System.out.println(accList);
		PreparedStatement pstmt1 = conn.prepareStatement("select * from Account");
		ResultSet accountRS = pstmt1.executeQuery();
		ArrayList<Account> accList = new ArrayList<Account>();
		while(accountRS.next()){
			long accountNo = accountRS.getLong("accountNo");
			String accountType = accountRS.getString("accountType");
			String status = accountRS.getString("status");
			int pinNumber = accountRS.getInt("pinNumber");
			float accountBalance = accountRS.getFloat("accountBalance");
			Account account = new Account(pinNumber, accountType, status, accountBalance, accountNo,null);
			
			/*PreparedStatement pstmt2 = conn.prepareStatement("select * from Transaction where accountNo="+accountNo);
			ResultSet transactionRS = pstmt2.executeQuery();
			transactionRS.next();
			float amount = transactionRS.getFloat("amount");
			int transactionId = transactionRS.getInt("transactionId");
			String transactionType = transactionRS.getString("transactionType");
			account.setTransaction(new Transaction(transactionId, amount, transactionType));*/
			accList.add(account);	
		}
		return accList;
	}
	@Override
	public ArrayList<Transaction> allTransactions(long accountNo) throws SQLException {
		ArrayList<Transaction> tranList = new ArrayList<Transaction>();
		PreparedStatement pstmt1 = conn.prepareStatement("select * from Transaction where accountNo="+accountNo);
		ResultSet transactionRS = pstmt1.executeQuery();
		while(transactionRS.next()){
			int transactionId = transactionRS.getInt("transactionId");
			String transactionType = transactionRS.getString("transactionType");
			float amount = transactionRS.getFloat("amount");
			Transaction transaction = new Transaction(accountNo, transactionId, amount, transactionType);
			tranList.add(transaction);
		}
		return tranList;
	}
	@Override
	public float updateDeposit(long accountNo,float amount) throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("Update Account set accountBalance =? where accountNo=?");
		pstmt1.setFloat(1,find(accountNo).getAccountBalance()+amount);
		pstmt1.setLong(2, accountNo);

		
		PreparedStatement pstmt2 = conn.prepareStatement("insert into Transaction(transactionId,accountNo,amount,transactionType) values(transaction_seq.nextval,?,?,?)");
		pstmt2.setLong(1, accountNo);
		pstmt2.setFloat(2,amount);
		pstmt2.setString(3, "Deposit");
		pstmt2.executeUpdate();
		return find(accountNo).getAccountBalance();
	}
	@Override
	public float updateWithdraw(long accountNo,float amount) throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("Update Account set accountBalance =? where accountNo=?");
		pstmt1.setFloat(1,find(accountNo).getAccountBalance()-amount);
		pstmt1.setLong(2, accountNo);

		
		PreparedStatement pstmt2 = conn.prepareStatement("insert into Transaction(transactionId,accountNo,amount,transactionType) values(transaction_seq.nextval,?,?,?)");
		pstmt2.setLong(1, accountNo);
		pstmt2.setFloat(2,amount);
		pstmt2.setString(3, "Withdraw");
		pstmt2.executeUpdate();
		return find(accountNo).getAccountBalance();
	}	

}