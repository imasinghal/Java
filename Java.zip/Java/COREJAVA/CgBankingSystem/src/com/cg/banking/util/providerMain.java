package com.cg.banking.util;


public class providerMain {

	public static void main(String[] args) {
		if(ConnectionProvider.getDBConnection()==null)
			System.out.println("No Connection");
		else 
			System.out.println("Connection Done");
	}
}
