/*public class MyThread extends Thread{
	public MyThread(String name) {
		super(name);
	}
	@Override
	public void run(){
		if(this.getName().equals("Odd"))
			for(int i=1;i<=100;i=i+2)
				System.out.println(i);
		if(this.getName().equals("Even"))
			for(int i=0;i<=100;i=i+2)
				System.out.println(i);
	}
}*/
public class RunnableResource implements Runnable{

	@Override
	public void run() {
		Thread p = Thread.currentThread();
		if(p.getName().equals("Odd"))
			for(int i=1;i<=100;i=i+2)
				System.out.println(i);
		if(p.getName().equals("Even"))
			for(int i=0;i<=100;i=i+2)
				System.out.println(i);

	}
}
