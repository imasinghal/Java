public class MainClass {
	/*public static void main(String[] args) {
		MyThread th1= new MyThread("Odd"); 
		MyThread th2= new MyThread("Even");
		th1.start();
		th2.start();
	}
}*/
	public static void main(String[] args) {
		/*RunnableResource r1=new RunnableResource();
		Thread th1= new Thread(r1, "Odd"); 
		Thread th2= new Thread(r1, "Even");
		th1.start();
		th2.start();*/
		Runnable RunnableResource=() ->{
			for (int i = 1; i < 10; i++) 
			System.out.println("Tick "+i);			
		};
		Thread th1= new Thread(RunnableResource); 
		th1.start();
	}
}
