package com.cg.payroll.controllers;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

public class PayrollController {
	@GET
	@Path("hello")
	public String sayHello(){
		return "Heyyyyy";
	}

}
