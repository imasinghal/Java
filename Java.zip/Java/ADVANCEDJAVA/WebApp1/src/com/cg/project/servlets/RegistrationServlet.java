package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

import com.cg.project.beans.Associate;
@WebServlet("/Registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String date = request.getParameter("date");
		String[] hobbies = request.getParameterValues("hobbies");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		
		Associate associate = new Associate(firstName, lastName, date, email, phone, hobbies);
		RequestDispatcher dispatcher;
		dispatcher = request.getRequestDispatcher("registrationSuccessPage.jsp");
		request.setAttribute("associate", associate);
		dispatcher.forward(request, response);
		
		/*PrintWriter out = response.getWriter();
		out.print("<html><body><div align='center'><font color='red'>Welcome "+firstName+"</font></div><table align='center' border : 2px>");
		out.print("<tr><td>First Name</td><td>Last Name</td><td>DOB</td><td>Hobbies</td><td>Phone Number</td><td>Email</td></tr>");
		out.print("<tr><td>"+firstName+"</td><td>"+lastName+"</td><td>"+date+"</td><td>");
			for(String string : hobbies){
				out.print(string+" ");
			}
		out.print("<td>"+phone+"</td><td>"+email+"</td></tr>");
		out.print("</table></body></html>");*/
	}

}
