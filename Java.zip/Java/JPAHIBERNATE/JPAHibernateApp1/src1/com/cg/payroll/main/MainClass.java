package com.cg.payroll.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.dao.AssociateDAO;
import com.cg.payroll.dao.AssociateDAOImpl;

public class MainClass {
	public static void main(String[] args) {
		AssociateDAOImpl  dao = new AssociateDAOImpl();

		
		
		/*Associate associate = new Associate("Anmol", "Singhal","abc@gmail.com","Sr. Anlst");
		associate = dao.save(associate);
		int associateId = associate.getAssociateID();
		System.out.println(associateId);
		System.out.println(dao.findOne(101));
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager = factory.createEntityManager();*/
		
	}
}