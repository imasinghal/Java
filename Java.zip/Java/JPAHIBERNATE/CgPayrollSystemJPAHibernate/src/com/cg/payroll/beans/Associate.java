package com.cg.payroll.beans;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@SequenceGenerator(initialValue=101, name = "associate_seq",allocationSize=10)

@Entity     //this will make table with name associate
public class Associate {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="associate_seq")
	private int associateId;
	private String firstName,lastName,email,designation;
	int yearlyInvestmentUnder80C;
	@Embedded
	private BankDetails bankDetails;
	@Embedded
	private Salary salary;
	
	public Associate(String firstName, String lastName, String email,
			String designation, int yearlyInvestmentUnder80C,
			BankDetails bankDetails, Salary salary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.designation = designation;
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
		this.bankDetails = bankDetails;
		this.salary = salary;
	}
	public int getYearlyInvestmentUnder80C() {
		return yearlyInvestmentUnder80C;
	}
	public void setYearlyInvestmentUnder80C(int yearlyInvestmentUnder80C) {
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
	}
	public Associate(int associateId, String firstName, String lastName,
			String email, String designation, int yearlyInvestmentUnder80C,
			BankDetails bankDetails, Salary salary) {
		super();
		this.associateId = associateId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.designation = designation;
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
		this.bankDetails = bankDetails;
		this.salary = salary;
	}
	public Associate(int associateId, String firstName, String lastName,
			String email, String designation, BankDetails bankDetails,
			Salary salary) {
		super();
		this.associateId = associateId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.designation = designation;
		this.bankDetails = bankDetails;
		this.salary = salary;
	}
	public Associate() {}
	public int getAssociateId() {
		return associateId;
	}

	public BankDetails getBankDetails() {
		return bankDetails;
	}
	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}
	public Salary getSalary() {
		return salary;
	}
	public void setSalary(Salary salary) {
		this.salary = salary;
	}
	public Associate(int associateId, String firstName, String lastName,
			String email, String designation) {
		super();
		this.associateId = associateId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.designation = designation;
	}
	public Associate(String firstName, String lastName, String email,
			String designation) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.designation = designation;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", email=" + email
				+ ", designation=" + designation
				+ ", yearlyInvestmentUnder80C=" + yearlyInvestmentUnder80C
				+ ", bankDetails=" + bankDetails + ", salary=" + salary + "]";
	}
	public Associate(String firstName, String lastName, String email,
			String designation, BankDetails bankDetails, Salary salary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.designation = designation;
		this.bankDetails = bankDetails;
		this.salary = salary;
	}
}
