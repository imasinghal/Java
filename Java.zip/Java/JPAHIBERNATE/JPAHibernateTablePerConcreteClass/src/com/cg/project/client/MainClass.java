package com.cg.project.client;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.project.beans.Employee;

public class MainClass {
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		Employee emp = new Employee(101, "ASD", "dfg", "Asad@sfdgha");
	}
}
