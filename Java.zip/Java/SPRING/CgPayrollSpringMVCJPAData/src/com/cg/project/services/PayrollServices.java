package com.cg.project.services;

import java.util.ArrayList;

import com.cg.project.beans.Associate;
/*import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;*/
import com.cg.project.exceptions.AssociateDetailsNotFoundException;


public interface PayrollServices {
	Associate acceptAssociateDetails(Associate associate);

	int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException;

	ArrayList<Associate> getAllAssociateDetails();
	ArrayList<Associate> findFewAssociate(int yearlyInvestmentUnder80C);
	//ArrayList<Associate> getAllAssociateDetails() throws PayrollServicesDownException;
}