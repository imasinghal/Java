package com.cg.project.services;

public class GreetingServicesImpl implements GreetingServices{

	@Override
	public void greetUser(String name) {
		System.out.println("Hello "+name);
	}
	

}
