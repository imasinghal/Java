package com.cg.payroll.client;
import java.util.Vector;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices = (PayrollServices) context.getBean("payrollServices");
		try {
			int associateId = payrollServices.acceptAssociateDetails("Anmol", "Singhal", "anm@gmail.com", "NFS", "Sr.Con", "nhf1dfgd23fd", 12000, 20000, 1000, 1000, 1212354, "hdfc", "hdfc00025");
		} catch (PayrollServicesDownException e) {
			e.printStackTrace();
			System.out.println("Payroll Services has down");
		}
		try {
			System.out.println("Net Salary : " + payrollServices.calculateNetSalary(101));
		} catch (AssociateDetailNotFoundException | PayrollServicesDownException e) {
			e.printStackTrace();
			System.out.println("Associate Detail Not Found"); 
		}
		try {
			System.out.println(payrollServices.getAssociateDetails(101));
		} catch (PayrollServicesDownException e) {
			System.out.println("Payroll Services has down");
			e.printStackTrace();
		} catch (AssociateDetailNotFoundException e) {
			System.out.println("Associate Detail Not Found");
			e.printStackTrace();
		}
		try {
			payrollServices.getAllAssociateDetails();
		} catch (PayrollServicesDownException e) {
			System.out.println("Payroll Services has down");
			e.printStackTrace();
		}
	}
}
