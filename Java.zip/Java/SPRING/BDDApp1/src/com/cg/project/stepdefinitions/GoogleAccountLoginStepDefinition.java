package com.cg.project.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleAccountLoginStepDefinition {
	@Given("^User is on Google LoginPage$")
	public void user_is_on_Google_LoginPage() throws Throwable {

	}
	@When("^User enter his credentials$")
	public void user_enter_his_credentials() throws Throwable {

	}
	@Then("^User should be able to view his inbox$")
	public void user_should_be_able_to_view_his_inbox() throws Throwable {

	}
}
