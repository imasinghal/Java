package com.cg.project.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubAccountLoginStepDefinition {
	private WebDriver driver;
	
	@Given("^User is on Github LoginPage$")
	public void user_is_on_Github_LoginPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://github.com/login");
	}

	@When("^User enter his login credentials$")
	public void user_enter_his_login_credentials() throws Throwable {
		By by = By.name("login");
		WebElement searchTxt = driver.findElement(by);
		searchTxt.sendKeys("imasinghal");
		By by1 = By.name("password");
		WebElement searchTxt1 = driver.findElement(by1);
		searchTxt1.sendKeys("mcp706@@");	
		searchTxt.submit();
	}

	@Then("^User should be able to login$")
	public void user_should_be_able_to_login() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
	
	
}
