package com.cg.onlineshop.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.daoservices.ProductDAO;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
@Component(value="onlineShopServices")
public class OnlineShopServicesImpl implements OnlineShopServices {
	
	@Autowired
	ProductDAO productDAO;
	
	@Override
	public Product acceptProductDetails(Product product) {
		return productDAO.save(product);
	}

	@Override
	public List<Product> getAllProductDetails() {
		List<Product> list = productDAO.findAll();
		return list;
	}

	@Override
	public Product getProductDetails(int productId) throws ProductDetailsNotFoundException {
		try{Product product = productDAO.findOne(productId);
		}
		catch (Exception e) {
			new ProductDetailsNotFoundException("Product details for productId "+productId+" not found");		
		}
		return productDAO.findOne(productId);
	
	}

	@Override
	public void removeProductDetails(int productId) {
		productDAO.delete(productId);
		
	}

}
