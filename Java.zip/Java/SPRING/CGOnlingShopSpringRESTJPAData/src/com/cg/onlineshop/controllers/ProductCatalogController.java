package com.cg.onlineshop.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
import com.cg.onlineshop.services.OnlineShopServices;
@CrossOrigin
@RestController
public class ProductCatalogController {

	@Autowired
	OnlineShopServices onlineShopServices;

	@RequestMapping("/hello")
	public ResponseEntity<String> sayHello(){
		ResponseEntity<String> response = new ResponseEntity<String>("Hello to All",HttpStatus.OK);
		return response;
	}
	
	@RequestMapping(value="acceptProductDetails",method=RequestMethod.POST,
		 consumes="application/json")
	public ResponseEntity<String> acceptproductDetails(@RequestBody Product product){
		System.out.println(product.getProductId());
		onlineShopServices.acceptProductDetails(product);
		return new ResponseEntity<>("Product details successfully added",HttpStatus.OK);
	}
	
	
	@RequestMapping(value="findDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> findDetails(@ModelAttribute Product product) throws ProductDetailsNotFoundException{
		product=onlineShopServices.getProductDetails(product.getProductId());
		return new ResponseEntity<>(product.toString(),HttpStatus.OK);
	}
	
	@RequestMapping(value="findAll",method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Product>> findAll() throws ProductDetailsNotFoundException{
		List<Product> list= onlineShopServices.getAllProductDetails(); 
		
		return new ResponseEntity<>(list,HttpStatus.OK);
	}
	
	@RequestMapping(value="addBulkProductDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> addBulkProductDetails(@RequestBody ArrayList<Product> products){
		for (Product product2 : products) 
			onlineShopServices.acceptProductDetails(product2);
		return new ResponseEntity<>("Product details successfully added",HttpStatus.OK);
	}
}
